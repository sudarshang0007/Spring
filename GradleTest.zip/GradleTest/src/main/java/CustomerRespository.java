

import org.springframework.data.repository.CrudRepository;

public interface CustomerRespository extends CrudRepository<Customer, Long> {

}
