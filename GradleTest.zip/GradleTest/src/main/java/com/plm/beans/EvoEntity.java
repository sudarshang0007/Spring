package com.plm.beans;


public class EvoEntity {

	
	private Long entityId;
	
}
