package com.plm.repository;

import org.springframework.data.repository.CrudRepository;

import com.plm.beans.Role;

public interface RoleRepository extends CrudRepository<Role	, Long> {
 
}
